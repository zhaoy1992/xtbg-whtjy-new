-- ɾ������ 
delete from tb_process where p_id in('20100530091128976058') ; 
 commit; 
-- �������� 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20100530091128976058', '1192032', '20100430111825238919', 'test009#3#test009_wp1', '����009','admin',  '31-5�� -10',  '0',  '',  '','0',  '0',  '0',  '','');
 commit; 


