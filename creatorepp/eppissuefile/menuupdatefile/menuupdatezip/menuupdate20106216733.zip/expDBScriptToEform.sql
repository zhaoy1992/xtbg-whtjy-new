-- ɾ������ 
delete from td_form_ctrlattr where djid in('20100602100918873865') ; 
 commit; 
delete from td_form_perattr where djid in('20100602100918873865') ; 
 commit; 
delete from tb_form_datastru where djid in('20100602100918873865') ; 
 commit; 
delete from tb_ctrl_design where djid in('20100602100918873865') ; 
 commit; 
delete from tb_form where djid in('20100602100918873865') ; 
 commit; 
delete fc_billzl tb_form where djid in('20100602100918873865') ; 
 commit; 
-- ������� 
insert into fc_billzl(djid,dj_name,djlx,djposition,djsn,isfunction,stmptable) values('20100602100918873865','test������','ZW','343,320,682,367,undefined,����������,�޸�,��ǰ����','20100602100918873865','','');
 commit; 
insert into tb_form(eform_id,djid,store_type,remark,dj_ver,dj_name,creator,creattime,publishstate,publishtime,publisher,dj_mtype,procattr,hasoffice,hasupload,hasgaeditor,ds_ids,dj_log,dj_protect,dj_modified,dj_editor,dj_edittime,hashtm,cssfolder) values('20090825142958890821','20100602100918873865','','','1.0', 'test������', 'admin', '03-6�� -10', '1', '03-6�� -10','admin', '0', '1', '0', '0','0', '', '0', '1', '0','', '', '0', 'creatorBlue');
 commit; 


