-- ɾ������ 
delete from td_form_ctrlattr where djid in('20100517162920218608') ; 
 commit; 
delete from td_form_perattr where djid in('20100517162920218608') ; 
 commit; 
delete from tb_form_datastru where djid in('20100517162920218608') ; 
 commit; 
delete from tb_ctrl_design where djid in('20100517162920218608') ; 
 commit; 
delete from tb_form where djid in('20100517162920218608') ; 
 commit; 
delete fc_billzl tb_form where djid in('20100517162920218608') ; 
 commit; 
-- ������� 
insert into fc_billzl(djid,dj_name,djlx,djposition,djsn,isfunction,stmptable) values('20100517162920218608','fusionchart ����','ZW','344,299,679,388,undefined,����������,�޸�,��ǰ����','20100517162920218608','','');
 commit; 
insert into tb_form(eform_id,djid,store_type,remark,dj_ver,dj_name,creator,creattime,publishstate,publishtime,publisher,dj_mtype,procattr,hasoffice,hasupload,hasgaeditor,ds_ids,dj_log,dj_protect,dj_modified,dj_editor,dj_edittime,hashtm,cssfolder) values('20090902155009062414','20100517162920218608','','','1.0', 'fusionchart ����', 'admin', '17-5�� -10', '0', '','', '0', '0', '0', '0','0', 'dataset1', '0', '1', '0','', '', '0', 'creatorBlue');
 commit; 
insert into tb_form_datastru(frmstru_id,djid,ds_id,ds_type,ds_sql,ds_tbname,remark,uploadattr,ds_primary) values('20100517163010374312', '20100517162920218608', 'dataset1', '1', '','', '', '0','');
 commit; 


