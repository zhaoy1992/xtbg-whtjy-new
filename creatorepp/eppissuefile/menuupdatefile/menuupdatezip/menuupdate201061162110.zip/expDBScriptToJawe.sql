-- ɾ������ 
delete from tb_process where p_id in('20100505170858999675','20100505154650031782') ; 
 commit; 
-- �������� 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20100505154650031782', '1191793', '20090902155009062414', 'test31#5#test31_wp1', '121321','admin',  '05-5�� -10',  '0',  '',  '','0',  '0',  '1',  '05-5�� -10','admin');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20100505170858999675', '1073754', '20090902155009062414', 'test32#1#test32_wp1', '���Թ���ָ�','admin',  '05-5�� -10',  '0',  '',  '','0',  '0',  '1',  '05-5�� -10','admin');
 commit; 


