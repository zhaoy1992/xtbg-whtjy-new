-- ɾ������ 
delete from td_form_ctrlattr where djid in('20090811143017375143','20100524101032750153') ; 
 commit; 
delete from td_form_perattr where djid in('20090811143017375143','20100524101032750153') ; 
 commit; 
delete from tb_form_datastru where djid in('20090811143017375143','20100524101032750153') ; 
 commit; 
delete from tb_ctrl_design where djid in('20090811143017375143','20100524101032750153') ; 
 commit; 
delete from tb_form where djid in('20090811143017375143','20100524101032750153') ; 
 commit; 
delete fc_billzl tb_form where djid in('20090811143017375143','20100524101032750153') ; 
 commit; 
-- ������� 
insert into fc_billzl(djid,dj_name,djlx,djposition,djsn,isfunction,stmptable) values('20090811143017375143','����������','ZW','319,249,704,440,undefined,����������,�޸�,��ǰ����','20090811143017375143','','');
 commit; 
insert into fc_billzl(djid,dj_name,djlx,djposition,djsn,isfunction,stmptable) values('20100524101032750153','��ȫ�Բ���','ZW','344,277,679,410,undefined,����������,�޸�,��ǰ����','20100524101032750153','','');
 commit; 
insert into tb_form(eform_id,djid,store_type,remark,dj_ver,dj_name,creator,creattime,publishstate,publishtime,publisher,dj_mtype,procattr,hasoffice,hasupload,hasgaeditor,ds_ids,dj_log,dj_protect,dj_modified,dj_editor,dj_edittime,hashtm,cssfolder) values('20090810102954968085','20090811143017375143','','','1.0', '����������', 'admin', '11-8�� -09', '2', '20-8�� -09','admin', '0', '1', '0', '0','0', 'dataset1', '0', '1', '0','', '', '0', 'creatorBlue');
 commit; 
insert into tb_form(eform_id,djid,store_type,remark,dj_ver,dj_name,creator,creattime,publishstate,publishtime,publisher,dj_mtype,procattr,hasoffice,hasupload,hasgaeditor,ds_ids,dj_log,dj_protect,dj_modified,dj_editor,dj_edittime,hashtm,cssfolder) values('20100429103033952469','20100524101032750153','','','1.0', '��ȫ�Բ���', 'admin', '24-5�� -10', '1', '19-8�� -09','admin', '0', '1', '0', '0','0', 'dataset1', '0', '1', '0','', '', '0', 'creatorBlue');
 commit; 
insert into tb_form_datastru(frmstru_id,djid,ds_id,ds_type,ds_sql,ds_tbname,remark,uploadattr,ds_primary) values('20090811143017500846', '20090811143017375143', 'dataset1', '1', '','TA_TEST', '', '0','');
 commit; 
insert into tb_form_datastru(frmstru_id,djid,ds_id,ds_type,ds_sql,ds_tbname,remark,uploadattr,ds_primary) values('20100524101032890422', '20100524101032750153', 'dataset1', '1', '','TA_TEST', '', '0','');
 commit; 
insert into td_form_perattr(perattr_id,djid,oid,ctrl_id,perattr_type,remark,readonlystyle) values('9faa8295-52e7-457c-90d1-bddbe0e37a9f', '20100524101032750153', 'test118_wp1_act3', '20100524101032750153text1', '-2','','');
 commit; 
insert into td_form_ctrlattr(ctrlattr_id,djid,oid,ctrl_id,ctrl_cnname,field_type,init_value,field_desc) values('dfd51743-e60d-4cc2-bdc4-8bb8c89d0f0f', '20100524101032750153', 'test118_wp1', 'F_20100524101032750153text1', '','6', '','');
 commit; 
insert into td_form_ctrlattr(ctrlattr_id,djid,oid,ctrl_id,ctrl_cnname,field_type,init_value,field_desc) values('8e4b1050-fc79-4d1c-bf7f-dd31e6299d04', '20090811143017375143', 'test17_wp1', 'F_20090811143017375143text1', '','6', '','');
 commit; 
insert into td_form_ctrlattr(ctrlattr_id,djid,oid,ctrl_id,ctrl_cnname,field_type,init_value,field_desc) values('59cb53eb-4acc-4e47-87d7-0e4545dd8f5f', '20100524101032750153', 'binlian_wp1', 'F_20100524101032750153text2', '','6', '','');
 commit; 
insert into td_form_ctrlattr(ctrlattr_id,djid,oid,ctrl_id,ctrl_cnname,field_type,init_value,field_desc) values('5ddba253-d7e8-43c4-a735-4390680698fb', '20100524101032750153', 'test889_wp1', 'F_20100524101032750153text1', '','6', '','');
 commit; 
insert into td_form_ctrlattr(ctrlattr_id,djid,oid,ctrl_id,ctrl_cnname,field_type,init_value,field_desc) values('d6265a18-48f0-4ba8-b1fd-0d9c999f4d88', '20090811143017375143', 'test11_wp1', 'F_20090811143017375143text1', '','6', '','');
 commit; 
insert into td_form_ctrlattr(ctrlattr_id,djid,oid,ctrl_id,ctrl_cnname,field_type,init_value,field_desc) values('bbc27884-05b6-4e08-b7b4-b056a9f95a6e', '20100524101032750153', 'binlian_wp1', 'F_20100524101032750153text1', '','6', '','');
 commit; 
insert into td_form_ctrlattr(ctrlattr_id,djid,oid,ctrl_id,ctrl_cnname,field_type,init_value,field_desc) values('1a097f9a-08c2-4347-af03-79838f72c221', '20100524101032750153', 'test110_wp1', 'F_20100524101032750153text1', '','6', '','');
 commit; 


