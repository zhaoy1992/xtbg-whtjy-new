-- ɾ������ 
delete from tb_process where p_id in('20090715091658182503','20090811143257828341','20090812114930468297','20090812150848187820','20090813112237781688','20090814114212203964','20090819143812609007','20090820130202125035','20090901102411468921','20090901105745375567','20090901161437984735','20090902093405015344','20090902103011937941','20090902151012281930','20090902162542812365','20090902164059437754','20100607105552118737') ; 
 commit; 
-- �������� 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20090715091658182503', '1582016', '20100607093706211537', 'testqzhd#2#testqzhd_wp1', '����ǰ�ûִ����','admin',  '19-7�� -09',  '0',  '',  '','0',  '0',  '1',  '19-7�� -09','admin');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20090813112237781688', '2235571', '20090810102954968085', 'test5#27#test5_wp1', '��������Դ��ָ̬��','admin',  '13-8�� -09',  '0',  '',  '','0',  '0',  '0',  '','');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20090820130202125035', '3085140', '20090810102954968085', 'test8#28#test8_wp1', '���Ի����','admin',  '20-8�� -09',  '0',  '',  '','0',  '0',  '0',  '','');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20090812150848187820', '3138162', '20090810102954968085', 'test4#25#test4_wp1', '����JSP�ļ�','admin',  '12-8�� -09',  '0',  '',  '','0',  '0',  '0',  '','');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20090902151012281930', '1726694', '20090810102954968085', 'test15#25#test15_wp1', '','admin',  '02-9�� -09',  '0',  '',  '','0',  '0',  '0',  '','');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20090819143812609007', '3085230', '20090810102954968085', 'test7#27#test7_wp1', '���Ի�Զ����','admin',  '19-8�� -09',  '0',  '',  '','0',  '0',  '0',  '','');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20090901105745375567', '1726730', '20090810102954968085', 'test12#24#test12_wp1', '�������֧','admin',  '01-9�� -09',  '0',  '',  '','0',  '0',  '0',  '','');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20090814114212203964', '4400115', '20090810102954968085', 'test6#27#test6_wp1', '���Ը����빤��������','admin',  '14-8�� -09',  '0',  '',  '','0',  '0',  '0',  '','');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20100607105552118737', '1582066', '20100607093706211537', 'testWord#2#testWord_wp1', 'word״̬����','admin',  '08-6�� -10',  '0',  '',  '','0',  '0',  '1',  '08-6�� -10','admin');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20090902093405015344', '1726712', '20090810102954968085', 'test14#24#test14_wp1', '','admin',  '02-9�� -09',  '0',  '',  '','0',  '0',  '0',  '','');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20090812114930468297', '4337393', '20090810102954968085', 'test3#30#test3_wp1', '����������','admin',  '12-8�� -09',  '0',  '',  '','0',  '0',  '0',  '','');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20090811143257828341', '4403253', '20090810102954968085', 'test2#40#test2_wp1', '�����������','admin',  '11-8�� -09',  '0',  '',  '','0',  '0',  '0',  '','');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20090901102411468921', '4374653', '20090810102954968085', 'test11#30#test11_wp1', '����������֧','admin',  '01-9�� -09',  '0',  '',  '','0',  '0',  '0',  '','');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20090902164059437754', '1726718', '20090810102954968085', 'test17#24#test17_wp1', '','admin',  '02-9�� -09',  '0',  '',  '','0',  '0',  '0',  '','');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20090901161437984735', '2454587', '20090810102954968085', 'test13#25#test13_wp1', '���Զ�̬ѡ���¸��','admin',  '01-9�� -09',  '0',  '',  '','0',  '0',  '0',  '','');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20090902162542812365', '1726745', '20090810102954968085', 'test16#25#test16_wp1', '','admin',  '02-9�� -09',  '0',  '',  '','0',  '0',  '0',  '','');
 commit; 
insert into tb_process(p_id,oid,ec_id,p_name,remark,creator,creattime,checkoutstate,checker,checkouttime,p_type,issaveactdata,publishstate,publishtime,publisher) values('20090902103011937941', '1726700', '20090810102954968085', 'zhudiao#25#zhudiao_wp1', '','admin',  '02-9�� -09',  '0',  '',  '','0',  '0',  '0',  '','');
 commit; 


