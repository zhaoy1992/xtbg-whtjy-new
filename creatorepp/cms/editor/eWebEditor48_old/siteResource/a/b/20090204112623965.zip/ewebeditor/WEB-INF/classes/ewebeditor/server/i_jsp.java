package ewebeditor.server;

import java.util.*;
import java.util.regex.*;
import java.text.*;
import java.io.*;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;

public class i_jsp{
		
	protected HttpServletRequest m_request;
	protected HttpServletResponse m_response;
	protected ServletContext m_application;
	protected PageContext m_pagecontext;
	protected PrintWriter out; 

	private ewebeditor.server.util myUtil;

	private String sFileSeparator;

	private String sConfig;
	private String sLicense;
	private ArrayList aStyle;
	private ArrayList aToolbar;

	public i_jsp(){
		myUtil = new ewebeditor.server.util();
		sFileSeparator = System.getProperty("file.separator");
	}


	public final void Load(PageContext pagecontext) throws ServletException,IOException{
		m_pagecontext = pagecontext;
		m_application = pagecontext.getServletContext();
		m_request = (HttpServletRequest)pagecontext.getRequest();
		m_response = (HttpServletResponse)pagecontext.getResponse();
		out = m_response.getWriter();

		String s_Path = m_request.getServletPath();
		s_Path = s_Path.substring(0, s_Path.lastIndexOf("/"));
		s_Path = s_Path.substring(0, s_Path.lastIndexOf("/"));
		s_Path = m_application.getRealPath(s_Path);
		
		if (s_Path.substring(s_Path.length()-1,s_Path.length()) != sFileSeparator){
			s_Path += sFileSeparator;
		}
		
		sConfig = myUtil.ReadFile(s_Path+"jsp"+sFileSeparator+"config.jsp");
		sLicense = myUtil.getConfigString("License", sConfig);

		String sAction = myUtil.dealNull(m_request.getParameter("action")).toUpperCase();
		if (sAction.equals("LICENSE")) {
			ShowLicense();
		}else if(sAction.equals("CONFIG")){
			ShowConfig();
		}
	}



	private void ShowLicense(){
		if (sLicense.equals("")){
			return;
		}
		
		String r = myUtil.dealNull(m_request.getParameter("r"));
		if (r.length()<10){
			return;
		}
		
		String s_Domain=m_request.getServerName().toLowerCase();
		if (s_Domain.equals("127.0.0.1") || s_Domain.equals("localhost")) {
			return;
		}

		String ret="";
		String[] aa = myUtil.split(sLicense, ";");
		for (int i=0; i<aa.length; i++) {
			String[] a = myUtil.split(aa[i], ":");
			if (a.length==8){
				if (a[7].length()==32){				
					if ((s_Domain.equals(a[6])) || (s_Domain.equals("www."+a[6]))){
						for (int j=0; j<=6; j++){
							ret=ret + a[j] + ":";
						}
						ret=ret + myUtil.MD5(a[7].substring(0,16)+r, 16) + myUtil.MD5(a[7].substring(16)+r, 16);
						break;
					}
				}
			}
		}
		out.print(ret);
	}


	private void ShowConfig(){
		aStyle = myUtil.getConfigArray("Style", sConfig);
		aToolbar = myUtil.getConfigArray("Toolbar", sConfig);

		String s_License="";
		if (myUtil.CheckLicense(m_request.getServerName(), sLicense)){
			s_License="ok";
		}

		String s_StyleName = myUtil.dealNull(m_request.getParameter("style"));
		
		int n_StyleID = 0;

		String[] aTmpStyle = new String[1];
		boolean b = false;

		for (int i = 0; i < aStyle.size(); i++){
			aTmpStyle = myUtil.split(aStyle.get(i).toString(), "|||");
			if (s_StyleName.toLowerCase().equals(aTmpStyle[0].toLowerCase())) {
				n_StyleID=i;
				b = true;
				break;
			}
		}

		if (!b) {
			return;
		}


		String ret = "";
		ret = ret + "config.FixWidth = \"" + aTmpStyle[1] + "\";" + "\r\n";

		if (aTmpStyle[19].equals("3")){
			ret = ret + "config.UploadUrl = \"" + aTmpStyle[23] + "\";" + "\r\n";
		}else{
			ret = ret + "config.UploadUrl = \"" + aTmpStyle[3] + "\";" + "\r\n";
		}

		ret = ret + "config.InitMode = \"" + aTmpStyle[18] + "\";" + "\r\n";
		ret = ret + "config.AutoDetectPasteFromWord = \"" + aTmpStyle[17] + "\";" + "\r\n";
		ret = ret + "config.BaseUrl = \"" + aTmpStyle[19] + "\";" + "\r\n";
		ret = ret + "config.BaseHref = \"" + aTmpStyle[22] + "\";" + "\r\n";
		ret = ret + "config.AutoRemote = \"" + aTmpStyle[24] + "\";" + "\r\n";
		ret = ret + "config.ShowBorder = \"" + aTmpStyle[25] + "\";" + "\r\n";
		ret = ret + "config.StateFlag = \"" + aTmpStyle[16] + "\";" + "\r\n";

		ret = ret + "config.SBCode = \"" + aTmpStyle[62] + "\";" + "\r\n";
		ret = ret + "config.SBEdit = \"" + aTmpStyle[63] + "\";" + "\r\n";
		ret = ret + "config.SBText = \"" + aTmpStyle[64] + "\";" + "\r\n";
		ret = ret + "config.SBView = \"" + aTmpStyle[65] + "\";" + "\r\n";
		ret = ret + "config.EnterMode = \"" + aTmpStyle[66] + "\";" + "\r\n";

		ret = ret + "config.Skin = \"" + aTmpStyle[2] + "\";" + "\r\n";
		ret = ret + "config.AllowBrowse = \"" + aTmpStyle[43] + "\";" + "\r\n";
		ret = ret + "config.AllowImageSize = \"" + aTmpStyle[13] + "\";" + "\r\n";
		ret = ret + "config.AllowFlashSize = \"" + aTmpStyle[12] + "\";" + "\r\n";
		ret = ret + "config.AllowMediaSize = \"" + aTmpStyle[14] + "\";" + "\r\n";
		ret = ret + "config.AllowFileSize = \"" + aTmpStyle[11] + "\";" + "\r\n";
		ret = ret + "config.AllowRemoteSize = \"" + aTmpStyle[15] + "\";" + "\r\n";
		ret = ret + "config.AllowLocalSize = \"" + aTmpStyle[45] + "\";" + "\r\n";

		ret = ret + "config.AllowImageExt = \"" + aTmpStyle[8] + "\";" + "\r\n";
		ret = ret + "config.AllowFlashExt = \"" + aTmpStyle[7] + "\";" + "\r\n";
		ret = ret + "config.AllowMediaExt = \"" + aTmpStyle[9] + "\";" + "\r\n";
		ret = ret + "config.AllowFileExt = \"" + aTmpStyle[6] + "\";" + "\r\n";
		ret = ret + "config.AllowRemoteExt = \"" + aTmpStyle[10] + "\";" + "\r\n";
		
		ret = ret + "config.AreaCssMode = \"" + aTmpStyle[67] + "\";" + "\r\n";
		ret = ret + "config.SYWZFlag = \"" + aTmpStyle[32] + "\";" + "\r\n";
		ret = ret + "config.SYTPFlag = \"" + aTmpStyle[52] + "\";" + "\r\n";
		
		ret = ret + "config.L = \"" + s_License + "\";" + "\r\n";
		ret = ret + "config.ServerExt = \"jsp\";" + "\r\n";

		ret = ret + "\r\n";
		ret = ret + "config.Toolbars = [\r\n";

		String s_Order = "";
		String s_ID = "";
		for (int n=0; n<aToolbar.size(); n++){
			if (!aToolbar.get(n).toString().equals("")){
				String[] aTmpToolbar = myUtil.split(aToolbar.get(n).toString(), "|||");
				if (aTmpToolbar[0].equals(String.valueOf(n_StyleID))) {
					if (!s_ID.equals("")){
						s_ID = s_ID + "|";
						s_Order = s_Order + "|";
					}
					s_ID = s_ID + String.valueOf(n);
					s_Order = s_Order + aTmpToolbar[3];
				}
			}
		}

		if (!s_ID.equals("")){
			String[] a_ID = myUtil.split(s_ID, "|");
			String[] a_Order = myUtil.split(s_Order, "|");

			for(int n=0; n<a_ID.length; n++){
				String[] aTmpToolbar = myUtil.split(aToolbar.get(Integer.valueOf(a_ID[n]).intValue()).toString(), "|||");
				String[] aTmpButton = myUtil.split(aTmpToolbar[1], "|");

				if (n>0){
					ret = ret + ",\r\n";
				}
				ret = ret + "\t[";

				for(int i=0; i<aTmpButton.length; i++){
					if (i > 0){
						ret = ret + ", ";
					}
					ret = ret + "\"" + aTmpButton[i] + "\"";
				}
				ret = ret + "]";
			}
		}

		ret = ret + "\r\n];\r\n";
		out.print(ret);
	}



}
