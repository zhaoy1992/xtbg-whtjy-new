package ewebeditor.server;

import java.util.*;
import java.util.regex.*;
import java.text.*;
import java.io.*;
import java.security.*;


public class util
{
		
	public util(){


	}


	public String[] split(String source, String div) {
		int arynum = 0, intIdx = 0, intIdex = 0, div_length = div.length();
		if (source.compareTo("") != 0) {
		  if (source.indexOf(div) != -1) {
			intIdx = source.indexOf(div);
			for (int intCount = 1; ; intCount++) {
			  if (source.indexOf(div, intIdx + div_length) != -1) {
				intIdx = source.indexOf(div, intIdx + div_length);
				arynum = intCount;
			  }
			  else {
				arynum += 2;
				break;
			  }
			}
		  }
		  else {
			arynum = 1;
		  }
		}
		else {
		  arynum = 0;

		}
		intIdx = 0;
		intIdex = 0;
		String[] returnStr = new String[arynum];

		if (source.compareTo("") != 0) {
		  if (source.indexOf(div) != -1) {
			intIdx = (int) source.indexOf(div);
			returnStr[0] = (String) source.substring(0, intIdx);
			for (int intCount = 1; ; intCount++) {
			  if (source.indexOf(div, intIdx + div_length) != -1) {
				intIdex = (int) source.indexOf(div, intIdx + div_length);
				returnStr[intCount] = (String) source.substring(intIdx + div_length,
					intIdex);
				intIdx = (int) source.indexOf(div, intIdx + div_length);
			  }
			  else {
				returnStr[intCount] = (String) source.substring(intIdx + div_length,
					source.length());
				break;
			  }
			}
		  }
		  else {
			returnStr[0] = (String) source.substring(0, source.length());
			return returnStr;
		  }
		}
		else {
		  return returnStr;
		}
		return returnStr;
	}

	public String dealNull(String str) {
		String returnstr = null;
		if (str == null) {
			returnstr = "";
		} else {
			returnstr = str;
		}
		return returnstr;
	}

	public Object dealNull(Object obj) {
		Object returnstr = null;
		if (obj == null){
			returnstr = (Object) ("");
		}else{
			returnstr = obj;
		}
		return returnstr;
	}

	public String replace(String str, String substr, String restr) {
		String[] tmp = split(str, substr);
		String returnstr = null;
		if (tmp.length != 0) {
			returnstr = tmp[0];
			for (int i = 0; i < tmp.length - 1; i++) {
				returnstr = dealNull(returnstr) + restr + tmp[i + 1];
			}
		}
		return dealNull(returnstr);
	}

	public String getConfigString(String s_Key, String s_Config){
		String s_Result = "";
		Pattern p = Pattern.compile("//" + s_Key + " = \"(.*)\"");
		Matcher m = p.matcher(s_Config);
		while (m.find()) {
			s_Result = m.group(1);
		}
		return s_Result;
	}

	public ArrayList getConfigArray(String s_Key, String s_Config){
		ArrayList a_Result = new ArrayList();
		Pattern p = Pattern.compile("//" + s_Key + " = \"(.*)\"");
		Matcher m = p.matcher(s_Config);
		while (m.find()) {
			a_Result.add(m.group(1));
		}
		return a_Result;
	}

	public String ReadFile(String s_FileName){
		String s_Result = "";
		try {
			File objFile = new File(s_FileName);
			char[] chrBuffer = new char[10];
			int intLength;
			if(objFile.exists()){
				FileReader objFileReader = new FileReader(objFile);
				while((intLength=objFileReader.read(chrBuffer))!=-1){
					s_Result += String.valueOf(chrBuffer,0,intLength);
				}
				objFileReader.close();
			}
		} catch(IOException e) {
			System.out.println(e.getMessage());
		}
		return s_Result;
	}


	public String formatDate(Date myDate, int nFlag) {
		String strFormat = "";
		switch(nFlag){
		case 1:
			strFormat = "yyyy";
			break;
		case 2:
			strFormat = "yyyyMM";
			break;
		case 3:
			strFormat = "yyyyMMdd";
			break;
		case 4:
			strFormat = "yyyyMMddHHmmss";
			break;
		case 5:
			strFormat = "yyyy-MM-dd";
			break;
		}
		SimpleDateFormat formatter = new SimpleDateFormat(strFormat);
		String strDate = formatter.format(myDate);
		return strDate;
	}

	public String MD5(String plainText, int len) { 
		try { 
			MessageDigest md = MessageDigest.getInstance("MD5"); 
			md.update(plainText.getBytes()); 
			byte b[] = md.digest(); 

			int i; 

			StringBuffer buf = new StringBuffer(""); 
			for (int offset = 0; offset < b.length; offset++) { 
				i = b[offset]; 
				if(i<0) i+= 256; 
				if(i<16) buf.append("0"); 
				buf.append(Integer.toHexString(i)); 
			} 
			
			if (len==16){
				return buf.toString().substring(8,24);
			}else{
				return buf.toString();
			}

		} catch (NoSuchAlgorithmException e) { 
			// TODO Auto-generated catch block 
			e.printStackTrace(); 
		}
		return "";
	} 

	public boolean CheckLicense(String s_Domain, String s_License){
		s_Domain=s_Domain.toLowerCase();
		if (s_Domain.equals("127.0.0.1") || s_Domain.equals("localhost")) {
			return true;
		}
		
		if (s_License.equals("")){
			return false;
		}

		String ret="";
		String[] aa = split(s_License, ";");
		for (int i=0; i<aa.length; i++) {
			String[] a = split(aa[i], ":");
			if (a.length==8){
				if (a[7].length()==32){				
					if ((s_Domain.equals(a[6])) || (s_Domain.equals("www."+a[6]))){
						return true;
					}
				}
			}
		}
		return false;
	}

	public boolean IsInt(String str){
		if (str.equals("")){
			return false;
		}

		Pattern p = Pattern.compile("[^0-9]+");
		Matcher m = p.matcher(str);
		if (m.matches()){
			return false;
		}

		return true;
	}

}
