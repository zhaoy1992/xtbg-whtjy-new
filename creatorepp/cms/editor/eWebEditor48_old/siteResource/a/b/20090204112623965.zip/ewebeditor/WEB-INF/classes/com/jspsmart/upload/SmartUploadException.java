package com.jspsmart.upload;

public class SmartUploadException extends Exception
{

    SmartUploadException(String s)
    {
        super(s);
    }
}
