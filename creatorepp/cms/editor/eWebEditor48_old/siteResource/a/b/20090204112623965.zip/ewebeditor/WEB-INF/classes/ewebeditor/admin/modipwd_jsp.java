package ewebeditor.admin;

import java.util.*;
import java.util.regex.*;
import java.text.*;
import java.io.*;


import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;


public class modipwd_jsp
{
		
	private HttpServletRequest m_request;
	private HttpServletResponse m_response;
	private HttpSession m_session;
	private ServletContext m_application;
	private PageContext m_pagecontext;
	private PrintWriter out; 

	private ewebeditor.admin.util myUtil;


	public modipwd_jsp(){
		myUtil = new ewebeditor.admin.util();
	}



	public final void Load(PageContext pagecontext) throws ServletException,IOException{
		m_pagecontext = pagecontext;
		m_application = pagecontext.getServletContext();
		m_request = (HttpServletRequest)pagecontext.getRequest();
		m_response = (HttpServletResponse)pagecontext.getResponse();
		m_session = (HttpSession)pagecontext.getSession();
		out = m_response.getWriter();

		
		if (!myUtil.InitAdmin(pagecontext, true)){
			return;
		}




		myUtil.sPosition = myUtil.sPosition + "�޸��û���������";

		out.print(myUtil.Header());


		if (myUtil.sAction.equals("MODI")) {
			String sNewUsr = myUtil.dealNull(m_request.getParameter("newusr"));
			String sNewPwd1 = myUtil.dealNull(m_request.getParameter("newpwd1"));
			String sNewPwd2 = myUtil.dealNull(m_request.getParameter("newpwd2"));

			if (sNewUsr.equals("")) {
				out.print(myUtil.getError("���û�������Ϊ�գ�"));
				return;
			}
			if (sNewPwd1.equals("")) {
				out.print(myUtil.getError("�����벻��Ϊ�գ�"));
				return;
			}
			if (!sNewPwd1.equals(sNewPwd2)) {
				out.print(myUtil.getError("�������ȷ�����벻��ͬ��"));
				return;
			}

			myUtil.sUsername = sNewUsr;
			myUtil.sPassword = sNewPwd1;

			myUtil.WriteConfig(myUtil.eWebEditorPath, myUtil.sLicense, myUtil.sUsername, myUtil.sPassword, myUtil.aStyle, myUtil.aToolbar);

			
			out.print("<table border=0 cellspacing=1 align=center class=navi>"+
			"<tr><th>" + myUtil.sPosition + "</th></tr>"+
			"</table><br>");

			

			out.print("<table border=0 cellspacing=1 align=center class=list>"+
			"<tr>"+
				"<td>��¼�û����������޸ĳɹ���</td>"+
			"</tr>"+
			"</table>");

		} else {

			out.print("<table border=0 cellspacing=1 align=center class=navi>"+
			"<tr><th>" + myUtil.sPosition + "</th></tr>"+
			"</table><br>");

			

			out.print("<table border=0 cellspacing=1 align=center class=form>"+
			"<form action='?action=modi' method=post name=myform onsubmit=\"return checkModipwdForm()\">"+
			"<tr>"+
				"<th>��������</th>"+
				"<th>������������</th>"+
				"<th>����˵��</th>"+
			"</tr>"+
			"<tr>"+
				"<td width='15%'>���û�����</td>"+
				"<td width='55%'><input type=text class=input size=20 name=newusr value=\"" + myUtil.htmlEncode(myUtil.sUsername) + "\"></td>"+
				"<td width='30%'><span class=red>*</span>&nbsp;&nbsp;���û�����<span class=blue>" + myUtil.htmlEncode(myUtil.sUsername) + "</span></td>"+
			"</tr>"+
			"<tr>"+
				"<td width='15%'>�� �� �룺</td>"+
				"<td width='55%'><input type=password class=input size=20 name=newpwd1 maxlength=30></td>"+
				"<td width='30%'><span class=red>*</span></td>"+
			"</tr>"+
			"<tr>"+
				"<td width='15%'>ȷ�����룺</td>"+
				"<td width='55%'><input type=password class=input size=20 name=newpwd2 maxlength=30></td>"+
				"<td width='30%'><span class=red>*</span></td>"+
			"</tr>"+
			"<tr><td align=center colspan=3><input type=submit name=bSubmit value='  �ύ  '></a>&nbsp;<input type=reset name=bReset value='  ����  '></td></tr>"+
			"</form>"+
			"</table>");


		}


		out.print(myUtil.Footer());


	}



}
