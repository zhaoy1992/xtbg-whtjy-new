package ewebeditor.server;

import java.util.*;
import java.util.regex.*;
import java.text.*;
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.geom.*;
import javax.imageio.*;
import javax.swing.*;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;

public class upload_jsp
{
		
	protected HttpServletRequest m_request;
	protected HttpServletResponse m_response;
	protected ServletContext m_application;
	protected PageContext m_pagecontext;
	protected PrintWriter out; 

	private String sAllowExt, sUploadDir, sBaseUrl, sContentPath, sNewDir;
	private int nAllowSize, nUploadObject, nAutoDir;
	private String sSYText, sSYFontColor, sSYFontName, sSYPicPath, sSLTSYExt, sSYShadowColor;
	private int nSLTFlag, nSLTMinSize, nSLTOkSize, nSYWZFlag, nSYFontSize, nSLTSYObject, nSYWZMinWidth, nSYShadowOffset, nSYWZMinHeight, nSYWZPosition, nSYWZTextWidth, nSYWZTextHeight, nSYWZPaddingH, nSYWZPaddingV, nSYTPFlag, nSYTPMinWidth, nSYTPMinHeight, nSYTPPosition, nSYTPPaddingH, nSYTPPaddingV, nSYTPImageWidth, nSYTPImageHeight, nCusDirFlag;
	private float nSYTPOpacity;

	// param
	private String sAction;
	private String sType;
	private String sStyleName;
	private String sCusDir;
	private String sParamSYFlag;
	private String sParamRnd;
	// interface
	private String sOriginalFileName;
	private String sSaveFileName;
	private String sPathFileName;

	private String sRealUploadPath;

	private ewebeditor.server.util myUtil;



	public upload_jsp(){
		sOriginalFileName = "";
		sSaveFileName = "";
		sPathFileName = "";
		myUtil = new ewebeditor.server.util();

	}


	public final void Load(PageContext pagecontext) throws ServletException,IOException
	{
		m_pagecontext = pagecontext;
		m_application = pagecontext.getServletContext();
		m_request = (HttpServletRequest)pagecontext.getRequest();
		m_response = (HttpServletResponse)pagecontext.getResponse();
		out = m_response.getWriter();

		InitUpload();
	}


	private void InitUpload() throws ServletException,IOException{
		String eWebEditorPath = m_request.getServletPath();
		eWebEditorPath = eWebEditorPath.substring(0, eWebEditorPath.lastIndexOf("/"));
		eWebEditorPath = eWebEditorPath.substring(0, eWebEditorPath.lastIndexOf("/"));
		eWebEditorPath = m_application.getRealPath(eWebEditorPath);

		String sFileSeparator = System.getProperty("file.separator");

		if (eWebEditorPath.substring(eWebEditorPath.length()-1,eWebEditorPath.length()) != sFileSeparator){
			eWebEditorPath += sFileSeparator;
		}
		
		String sConfig = myUtil.ReadFile(eWebEditorPath+"jsp"+sFileSeparator+"config.jsp");
		ArrayList aStyle = myUtil.getConfigArray("Style", sConfig);

	
		// param
		String s_QueryStr = m_request.getQueryString();
		String[] a_Params = myUtil.split(s_QueryStr, "&");
		HashMap params = new HashMap();
		for (int i=0; i<a_Params.length; i++){
			String[] a_Param = myUtil.split(a_Params[i], "=");
			if (a_Param.length==2){
				params.put(a_Param[0], a_Param[1]);
			}
		}

		sAction = myUtil.dealNull((String)params.get("action")).toUpperCase();
		sType = myUtil.dealNull((String)params.get("type")).toUpperCase();
		sStyleName = myUtil.dealNull((String)params.get("style"));
		sCusDir = myUtil.dealNull((String)params.get("cusdir"));
		sParamSYFlag = myUtil.dealNull((String)params.get("syflag"));
		sParamRnd = myUtil.dealNull((String)params.get("rnd"));
		

		// InitUpload

		sCusDir = myUtil.replace(sCusDir, "\\", "/");
		if ((sCusDir.startsWith("/")) || (sCusDir.startsWith(".")) || (sCusDir.endsWith(".")) || (sCusDir.indexOf("./")>=0) || (sCusDir.indexOf("/.")>=0) || (sCusDir.indexOf("//")>=0)){
			sCusDir = "";
		}


		String[] aStyleConfig = new String[1];
		boolean bValidStyle = false;

		for (int i = 0; i < aStyle.size(); i++){
			aStyleConfig = myUtil.split(aStyle.get(i).toString(), "|||");
			if (sStyleName.toLowerCase().equals(aStyleConfig[0].toLowerCase())) {
				bValidStyle = true;
				break;
			}
		}

		if (!bValidStyle) {
			OutScript("parent.UploadError('style')");
			return;
		}

		sBaseUrl = aStyleConfig[19];
		nUploadObject = Integer.valueOf(aStyleConfig[20]).intValue();
		nAutoDir = Integer.valueOf(aStyleConfig[21]).intValue();

		sUploadDir = aStyleConfig[3];
		if (!sBaseUrl.equals("3")){
			if (!sUploadDir.substring(0, 1).equals("/")) {
				sUploadDir = "../" + sUploadDir;
			}
		}

		if (sBaseUrl.equals("1")){
			sContentPath = RelativePath2RootPath(sUploadDir);
		} else if (sBaseUrl.equals("2")){
			sContentPath = RootPath2DomainPath(RelativePath2RootPath(sUploadDir));
		} else {
			//0,3
			sContentPath = aStyleConfig[23];
		}


		if (sType.equals("REMOTE")){
			sAllowExt = aStyleConfig[10];
			nAllowSize = Integer.valueOf(aStyleConfig[15]).intValue();
		} else if (sType.equals("FILE")){
			sAllowExt = aStyleConfig[6];
			nAllowSize = Integer.valueOf(aStyleConfig[11]).intValue();
		} else if (sType.equals("MEDIA")){
			sAllowExt = aStyleConfig[9];
			nAllowSize = Integer.valueOf(aStyleConfig[14]).intValue();
		} else if (sType.equals("FLASH")){
			sAllowExt = aStyleConfig[7];
			nAllowSize = Integer.valueOf(aStyleConfig[12]).intValue();
		} else if (sType.equals("LOCAL")){
			sAllowExt = aStyleConfig[44];
			nAllowSize = Integer.valueOf(aStyleConfig[45]).intValue();
		} else {
			sAllowExt = aStyleConfig[8];
			nAllowSize = Integer.valueOf(aStyleConfig[13]).intValue();
		}

		nSLTFlag = Integer.valueOf(aStyleConfig[29]).intValue();
		nSLTMinSize = Integer.valueOf(aStyleConfig[30]).intValue();
		nSLTOkSize = Integer.valueOf(aStyleConfig[31]).intValue();
		nSYWZFlag = Integer.valueOf(aStyleConfig[32]).intValue();
		sSYText = aStyleConfig[33];
		sSYFontColor = aStyleConfig[34];
		nSYFontSize = Integer.valueOf(aStyleConfig[35]).intValue();
		sSYFontName = aStyleConfig[36];
		sSYPicPath = aStyleConfig[37];
		nSLTSYObject = Integer.valueOf(aStyleConfig[38]).intValue();
		sSLTSYExt = aStyleConfig[39];
		nSYWZMinWidth = Integer.valueOf(aStyleConfig[40]).intValue();
		sSYShadowColor = aStyleConfig[41];
		nSYShadowOffset = Integer.valueOf(aStyleConfig[42]).intValue();
		nSYWZMinHeight = Integer.valueOf(aStyleConfig[46]).intValue();
		nSYWZPosition = Integer.valueOf(aStyleConfig[47]).intValue();
		nSYWZTextWidth = Integer.valueOf(aStyleConfig[48]).intValue();
		nSYWZTextHeight = Integer.valueOf(aStyleConfig[49]).intValue();
		nSYWZPaddingH = Integer.valueOf(aStyleConfig[50]).intValue();
		nSYWZPaddingV = Integer.valueOf(aStyleConfig[51]).intValue();
		nSYTPFlag = Integer.valueOf(aStyleConfig[52]).intValue();
		nSYTPMinWidth = Integer.valueOf(aStyleConfig[53]).intValue();
		nSYTPMinHeight = Integer.valueOf(aStyleConfig[54]).intValue();
		nSYTPPosition = Integer.valueOf(aStyleConfig[55]).intValue();
		nSYTPPaddingH = Integer.valueOf(aStyleConfig[56]).intValue();
		nSYTPPaddingV = Integer.valueOf(aStyleConfig[57]).intValue();
		nSYTPImageWidth = Integer.valueOf(aStyleConfig[58]).intValue();
		nSYTPImageHeight = Integer.valueOf(aStyleConfig[59]).intValue();
		nSYTPOpacity = Float.valueOf(aStyleConfig[60]).floatValue();
		nCusDirFlag = Integer.valueOf(aStyleConfig[61]).intValue();

		if (nSYWZFlag==2){
			if (sParamSYFlag.equals("1")){
				nSYWZFlag = 1;
			}else{
				nSYWZFlag = 0;
			}
		}
		if (nSYTPFlag==2){
			if (sParamSYFlag.equals("1")){
				nSYTPFlag = 1;
			}else{
				nSYTPFlag = 0;
			}
		}

		if (!myUtil.IsInt(sParamRnd)){
			sParamRnd = "";
		}

		if (!sBaseUrl.equals("3")){
			sRealUploadPath = m_application.getRealPath(RelativePath2RootPath2(sUploadDir));
		}else{
			sRealUploadPath = sUploadDir;
		}
		if (!sRealUploadPath.endsWith(sFileSeparator)){
			sRealUploadPath += sFileSeparator;
		}
		
		//if (sSYPicPath.startsWith("../")){
		//	sSYPicPath = sSYPicPath.substring(3);
		//}else if (sSYPicPath.startsWith("./")){
		//	sSYPicPath = "jsp/"+sSYPicPath.substring(2);
		//}else if (!sSYPicPath.startsWith("/")){
		//	sSYPicPath = "jsp/"+sSYPicPath;
		//}
		if (!sSYPicPath.equals("")){
			sSYPicPath = m_application.getRealPath(RelativePath2RootPath2(sSYPicPath));
		}


		// create dir
		if ((nCusDirFlag==1)&&(!sCusDir.equals(""))){
			String[] aTmp = myUtil.split(sCusDir, "/");
			for (int i = 0; i<aTmp.length; i++){
				if (!aTmp[i].equals("")){
					sRealUploadPath += aTmp[i] + sFileSeparator;
					sContentPath += aTmp[i] + "/";
					Mkdir(sRealUploadPath);
				}
			}
		}

		sNewDir = getNewDir(nAutoDir);
		if (!sNewDir.equals("")){
			sRealUploadPath += sNewDir + sFileSeparator;
			sContentPath += sNewDir + "/";
			Mkdir(sRealUploadPath);
		}

		if (sAction.equals("REMOTE")){
			DoRemote();

		} else if (sAction.equals("SAVE")){
			DoSave();

		} else if (sAction.equals("LOCAL")){
			DoLocal();

		}

	}

	


	private void DoRemote(){

			String sRemoteContent = myUtil.dealNull(m_request.getParameter("eWebEditor_UploadText"));
			if (!sAllowExt.equals("") && !sRemoteContent.equals("")){
				Pattern p = Pattern.compile("((http|https|ftp|rtsp|mms):(\\/\\/|\\\\\\\\){1}(([A-Za-z0-9_-])+[.]){1,}([A-Za-z0-9]{1,5})\\/(\\S+\\.(" + sAllowExt + ")))");
				Matcher m = p.matcher(sRemoteContent);
				ArrayList a_RemoteUrl = new ArrayList();
				String sRemoteurl = "";
				boolean bFind = false;
				while (m.find()) {
					sRemoteurl = sRemoteContent.substring(m.start(), m.end());
					bFind = false;
					for(int i=0; i<a_RemoteUrl.size(); i++){
						if (sRemoteurl.equals(a_RemoteUrl.get(i).toString())){
							bFind = true;
						}
					}
					if (bFind==false){
						a_RemoteUrl.add(sRemoteurl);
					}
				}

				String SaveFileType = "";
				String SaveFileName = "";
				for(int i=0; i<a_RemoteUrl.size(); i++){
					sRemoteurl = a_RemoteUrl.get(i).toString();
					SaveFileType = sRemoteurl.substring(sRemoteurl.lastIndexOf(".")+1);
					SaveFileName = GetRndFileName(SaveFileType);
					if (SaveRemoteFile(SaveFileName, sRemoteurl, sRealUploadPath)){
						if (!sOriginalFileName.equals("")){
							sOriginalFileName = sOriginalFileName + "|";
							sSaveFileName = sSaveFileName + "|";
							sPathFileName = sPathFileName + "|";
						}
						sOriginalFileName = sOriginalFileName + sRemoteurl.substring(sRemoteurl.lastIndexOf("/")+1);
						sSaveFileName = sSaveFileName + SaveFileName;
						sPathFileName = sPathFileName + sContentPath + SaveFileName;
						sRemoteContent = myUtil.replace(sRemoteContent, sRemoteurl, sContentPath + SaveFileName);
					}
				}
			}

			out.print("<html><head><title>eWebEditor</title><meta http-equiv='Content-Type' content='text/html; charset=gb2312'></head><body><input type=hidden id=UploadText value=\"" + inHTML(sRemoteContent) + "\"></body></html>");
			OutScript("parent.setHTML(UploadText.value);try{parent.addUploadFile('" + sOriginalFileName + "', '" + sSaveFileName + "', '" + sPathFileName + "');} catch(e){} parent.remoteUploadOK();");

	}




	private void DoSave() throws ServletException{
		out.print("<html><head><title>eWebEditor</title><meta http-equiv='Content-Type' content='text/html; charset=gb2312'></head><body>");

		String s_Flag = doingUpload();
		if (!s_Flag.equals("ok")){
			OutScript("parent.UploadError('"+s_Flag+"')");
			return;
		}

		String s_SmallImageFile, s_SmallImagePathFile, s_SmallImageScript;
		boolean b_SY;
		s_SmallImageFile = getSmallImageFile(sSaveFileName);
		s_SmallImagePathFile = "";
		s_SmallImageScript = "";
		if(makeImageSLT(sRealUploadPath, sSaveFileName, s_SmallImageFile)){
			b_SY = makeImageSY(sRealUploadPath + s_SmallImageFile);
			b_SY = makeImageSY(sRealUploadPath + sSaveFileName);
			s_SmallImagePathFile = sContentPath + s_SmallImageFile;
			s_SmallImageScript = "try{obj.addUploadFile('" + sOriginalFileName + "', '" + s_SmallImageFile + "', '" + s_SmallImagePathFile + "');} catch(e){} ";
		}else{
			s_SmallImageFile = "";
			b_SY = makeImageSY(sRealUploadPath + sSaveFileName);
		}

		sPathFileName = sContentPath + sSaveFileName;
		OutScript("parent.UploadSaved('" + sPathFileName + "','" + s_SmallImagePathFile + "');var obj=parent.dialogArguments;if((!obj.eWebEditor)||(!obj.eWebEditor_Temp_HTML)||(!obj.eWebEditor_UploadForm)){obj=parent.dialogArguments.dialogArguments;} try{obj.addUploadFile('" + sOriginalFileName + "', '" + sSaveFileName + "', '" + sPathFileName + "');} catch(e){} " + s_SmallImageScript);

	}


	private void DoLocal() throws ServletException{
		String s_Flag = doingUpload();
		if (!s_Flag.equals("ok")){
			return;
		}
		sPathFileName = sContentPath + sSaveFileName;
		out.print(sPathFileName);
	}


	private String doingUpload() throws ServletException{
		switch(nUploadObject){
		case 1:
			return doingUpload_CommonsFileUpload();
		case 0:
			return doingUpload_JspSmartUpload();
		}
		return "param";
	}

	private String doingUpload_CommonsFileUpload() throws ServletException{
		// Create a factory for disk-based file items
		org.apache.commons.fileupload.disk.DiskFileItemFactory factory = new org.apache.commons.fileupload.disk.DiskFileItemFactory();

		// Set factory constraints
		factory.setSizeThreshold(4096);
		factory.setRepository(new File(sRealUploadPath));

		// Create a new file upload handler
		org.apache.commons.fileupload.servlet.ServletFileUpload upload = new org.apache.commons.fileupload.servlet.ServletFileUpload(factory);

		// Set overall request size constraint
		upload.setSizeMax(nAllowSize*1024);
		//upload.setFileSizeMax(nAllowSize*1024);

		upload.setHeaderEncoding("gb2312");
		
		try {
			// Parse the request
			java.util.List items = upload.parseRequest(m_request);
			// Process the uploaded items
			Iterator iter = items.iterator();

			while (iter.hasNext()) { 
				org.apache.commons.fileupload.FileItem item = (org.apache.commons.fileupload.FileItem) iter.next();
				if (item.isFormField()) { continue;}	// Process a regular form field

				String s_FileName = item.getName();		// include path
				if (s_FileName != null) {
					s_FileName = org.apache.commons.io.FilenameUtils.getName(s_FileName);
				}

				long n_FileSize = item.getSize();
				if(s_FileName==null || s_FileName.equals("") || n_FileSize==0){
					continue;
				}

				String s_FileExt = s_FileName.substring(s_FileName.lastIndexOf(".")+1);
				if (!CheckValidExt(s_FileExt)){
					return "ext";
				}

				sOriginalFileName = s_FileName;
				sSaveFileName = GetRndFileName(s_FileExt);

				item.write(new File(sRealUploadPath+sSaveFileName)); 
			}
		}
		catch(Exception e){
			return "size";
		}
		return "ok";
	}

	private String doingUpload_JspSmartUpload() throws ServletException{
		com.jspsmart.upload.SmartUpload mySmartUpload = new com.jspsmart.upload.SmartUpload();
		mySmartUpload.initialize(m_pagecontext);
		mySmartUpload.setMaxFileSize(nAllowSize*1024);
		mySmartUpload.setCharset("gb2312");
		//String sAllowedFilesList = myUtil.replace(sAllowExt, "|", ",");
		//mySmartUpload.setAllowedFilesList(sAllowedFilesList);
		try {
			mySmartUpload.upload();
			com.jspsmart.upload.File oFile = mySmartUpload.getFiles().getFile(0);
			String s_FileExt = oFile.getFileExt().toLowerCase();
			if (!CheckValidExt(s_FileExt)){
				return "ext";
			}
			sOriginalFileName = oFile.getFileName();
			sSaveFileName = GetRndFileName(s_FileExt);
			oFile.saveAs(sRealUploadPath+sSaveFileName,oFile.SAVEAS_PHYSICAL);
		}
		catch(Exception e){
			return "size";
		}
		return "ok";
	}


	private String GetRndFileName(String s_FileExt){
		String s_Rnd;
		if (sParamRnd.equals("")){
			int i = (int)(Math.random()*900) + 100;
			s_Rnd = String.valueOf(i);
		}else{
			s_Rnd = sParamRnd;
		}
		String s_FileName = myUtil.formatDate(new Date(), 4) + s_Rnd + "." + s_FileExt;

		java.io.File f = new java.io.File(sRealUploadPath+s_FileName);
		if (f.exists()){
			return GetRndFileName(s_FileExt);
		}

		return s_FileName;
	}

	private void OutScript(String str){
		out.print("<script language=javascript>" + str + "</script>");
	}

	private boolean CheckValidExt(String sExt){
		String[] aExt = myUtil.split(sAllowExt, "|");
		for (int i = 0; i<aExt.length; i++){
			if (aExt[i].toLowerCase().equals(sExt.toLowerCase())) {
				return true;
			}
		}
		return false;
	}

	private String getNewDir(int n_AutoDir){
		switch(n_AutoDir){
		case 1:
			return myUtil.formatDate(new Date(), 1);
		case 2:
			return myUtil.formatDate(new Date(), 2);
		case 3:
			return myUtil.formatDate(new Date(), 3);
		default:
			return "";
		}
	}

	private void Mkdir(String path){
		java.io.File dir = new java.io.File(path);
		if (dir == null){
			return;
		}
		if (dir.isFile()){
			return;
		}
		if (!dir.exists()){
			boolean result = dir.mkdirs();
		}
	}

	private String RelativePath2RootPath(String url){
		String sTempUrl = url;
		if (sTempUrl.substring(0, 1).equals("/")){
			return sTempUrl;
		}

		String sWebEditorPath = m_request.getRequestURI();
		sWebEditorPath = sWebEditorPath.substring(0, sWebEditorPath.lastIndexOf("/"));
		while(sTempUrl.startsWith("../")){
			sTempUrl = sTempUrl.substring(3);
			sWebEditorPath = sWebEditorPath.substring(0, sWebEditorPath.lastIndexOf("/"));
		}
		return sWebEditorPath + "/" + sTempUrl;
	}

	private String RelativePath2RootPath2(String url){
		String sTempUrl = url;
		if (sTempUrl.substring(0, 1).equals("/")){
			return sTempUrl;
		}

		String sWebEditorPath = m_request.getServletPath();
		sWebEditorPath = sWebEditorPath.substring(0, sWebEditorPath.lastIndexOf("/"));
		while(sTempUrl.startsWith("../")){
			sTempUrl = sTempUrl.substring(3);
			sWebEditorPath = sWebEditorPath.substring(0, sWebEditorPath.lastIndexOf("/"));
		}
		return sWebEditorPath + "/" + sTempUrl;
	}

	private String RootPath2DomainPath(String url){
		String s_Protocol = m_request.getProtocol();
		String s_ServerName = m_request.getServerName();
		String s_ServerPort = String.valueOf(m_request.getServerPort());
		String sHost = myUtil.split(s_Protocol, "/")[0] + "://" + s_ServerName;
		String sPort = s_ServerPort;
		if (!sPort.equals("80")){
			sHost = sHost + ":" + sPort;
		}
		return sHost + url;
	}

	private String inHTML(int i){
		if (i=='&') return "&amp;";
		else if (i=='<') return "&lt;";
		else if (i=='>') return "&gt;";
		else if (i=='"') return "&quot;";
		else return ""+(char)i;
	}
		
	private String inHTML(String st){
		StringBuffer buf = new StringBuffer();
		for (int i = 0;i<st.length();i++){
			buf.append(inHTML(st.charAt(i)));
		}
		return buf.toString();
	}

	private boolean SaveRemoteFile(String s_LocalFileName, String s_RemoteFileUrl, String s_RealUploadPath){
		try{ 
			int httpStatusCode;
			URL url = new URL(s_RemoteFileUrl);
			URLConnection conn = url.openConnection();
			conn.connect();
			HttpURLConnection httpconn =(HttpURLConnection)conn;
			httpStatusCode =httpconn.getResponseCode();
			if(httpStatusCode!=HttpURLConnection.HTTP_OK){
				//file://HttpURLConnection return an error code
				//System.out.println("Connect to "+s_RemoteFileUrl+" failed,return code:"+httpStatusCode);
				return false;
			}
			int filelen = conn.getContentLength();
			InputStream is = conn.getInputStream();
			byte[] tmpbuf=new byte[1024];
			File savefile =new File(s_RealUploadPath + s_LocalFileName);
			if(!savefile.exists())
				savefile.createNewFile();
			FileOutputStream fos = new FileOutputStream(savefile);
			int readnum = 0;
			if(filelen<0){
				while(readnum>-1){
					readnum = is.read(tmpbuf);
					if(readnum>0)
						fos.write(tmpbuf,0,readnum);
				}
			}else{
				int readcount =0;
				while(readcount<filelen&&readnum!=-1){
					readnum=is.read(tmpbuf);
					if(readnum>0){
						fos.write(tmpbuf,0,readnum);
						readcount =readcount +readnum;
					}
				}
				if(readcount<filelen){
					System.out.println("download error");
					is.close();
					fos.close();
					savefile.delete();
					return false;
				}
			}
			fos.flush();
			fos.close();
			is.close();
		}
		catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}

	private String getSmallImageFile(String s_File){
		return s_File.substring(0, s_File.lastIndexOf(".")) + "_s" + s_File.substring(s_File.lastIndexOf("."));
	}

	private boolean isValidSLTSYExt(String s_File){
		String sExt = s_File.substring(s_File.lastIndexOf(".")+1).toLowerCase();
		String[] aExt = myUtil.split(sSLTSYExt.toLowerCase(), "|");
		for(int i=0;i<aExt.length;i++){
			if (aExt[i].equals(sExt)){
				return true;
			}
		}
		return false;
	}



	private boolean makeImageSY(String s_PathFile){
		if((nSYWZFlag==0)&&(nSYTPFlag==0)){ return false; }
		if(!isValidSLTSYExt(s_PathFile)){ return false; }

			ImageIcon imgIcon = new ImageIcon(s_PathFile);
			Image theImg = imgIcon.getImage(); 
			int width = theImg.getWidth(null);
			int height = theImg.getHeight(null);
			int posX, posY;
			
			BufferedImage bimage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = bimage.createGraphics();
			g.drawImage(theImg, 0, 0, null);
			if(nSYWZFlag==1){
				if((width<nSYWZMinWidth)||(height<nSYWZMinHeight)){return false;}
				posX = getSYPosX(nSYWZPosition, width, nSYWZTextWidth+nSYShadowOffset, nSYWZPaddingH);
				posY = getSYPosY(nSYWZPosition, height, nSYWZTextHeight+nSYShadowOffset, nSYWZPaddingV);

				Font wordFont = new Font(sSYFontName, Font.PLAIN, nSYFontSize);
				g.setFont(wordFont);
				FontMetrics fm = g.getFontMetrics();
				int a = fm.getAscent();

				//g.setBackground(Color.white);
				g.setColor(new Color(Integer.parseInt(sSYShadowColor ,16)));
				g.drawString(sSYText, posX+nSYShadowOffset, posY+a+nSYShadowOffset);
				g.setColor(new Color(Integer.parseInt(sSYFontColor ,16)));
				g.drawString(sSYText, posX, posY+a);
			}
			if(nSYTPFlag==1){
				if((width<nSYTPMinWidth)||(height<nSYTPMinHeight)){return false;}
				posX = getSYPosX(nSYTPPosition, width, nSYTPImageWidth, nSYTPPaddingH);
				posY = getSYPosY(nSYTPPosition, height, nSYTPImageHeight, nSYTPPaddingV);

				ImageIcon waterIcon = new ImageIcon(sSYPicPath);
				Image waterImg = waterIcon.getImage();
				g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_ATOP, nSYTPOpacity));
				g.drawImage(waterImg, posX, posY, null );
				//g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER));
			}
			g.dispose(); 
			try{ 
				File fo = new File(s_PathFile);
				ImageIO.write(bimage, "jpeg", fo);
			}catch(Exception e){ 
				return false; 
			}

		return true;
	}

	private int getSYPosX(int posFlag, int originalW, int syW, int paddingH){
		switch(posFlag){
		case 1:
		case 2:
		case 3:
			return paddingH;
		case 4:
		case 5:
		case 6:
			return (int)Math.floor((originalW - syW) / 2);
		case 7:
		case 8:
		case 9:
			return (originalW - paddingH - syW);
		default:
			return 0;
		}
	}

	private int getSYPosY(int posFlag, int originalH, int syH, int paddingV){
		switch(posFlag){
		case 1:
		case 4:
		case 7:
			return paddingV;
		case 2:
		case 5:
		case 8:
			return (int)Math.floor((originalH - syH) / 2);
		case 3:
		case 6:
		case 9:
			return (originalH - paddingV - syH);
		default:
			return 0;
		}
	}

	private boolean makeImageSLT(String s_Path, String s_File, String s_SmallFile){
		if(nSLTFlag==0){ return false; }
		if(!isValidSLTSYExt(s_Path+s_File)){ return false; }

		try {
			File fi = new File(s_Path + s_File);
			BufferedImage bis = ImageIO.read(fi);
			int w = bis.getWidth();
			int h = bis.getHeight();
			if((w<=nSLTMinSize)&&(h<=nSLTMinSize)){
				return false;
			}
			
			int nw,nh;
			double rate;
			if(w>h){
				nw = nSLTOkSize;
				rate = (double)nw/(double)w;
				nh = (int)(rate*(double)h);
			}else{
				nh = nSLTOkSize;
				rate = (double)nh/(double)h;
				nw = (int)(rate*(double)w);

			}

			File fo = new File(s_Path + s_SmallFile);
			BufferedImage bid = resizeImage(bis, nw, nh);
			ImageIO.write(bid,"jpeg",fo);
		} catch(Exception e){
			System.out.println(e);
			return false;
		}
		return true;
	}

	private BufferedImage resizeImage(BufferedImage source, int targetW, int targetH) {
		int type = source.getType();
		BufferedImage target = null;
		if (type == BufferedImage.TYPE_CUSTOM) {
			ColorModel cm = source.getColorModel();
			WritableRaster raster = cm.createCompatibleWritableRaster(targetW, targetH);
			boolean alphaPremultiplied = cm.isAlphaPremultiplied();
			target = new BufferedImage(cm, raster, alphaPremultiplied, null);
		} else
			target = new BufferedImage(targetW, targetH, type);
		Graphics2D g = target.createGraphics();
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
		double sx = (double) targetW / source.getWidth();
		double sy = (double) targetH / source.getHeight();
		g.drawRenderedImage(source, AffineTransform.getScaleInstance(sx, sy));
		g.dispose();
		return target;
	}







}
