package ewebeditor.server;

import java.util.*;
import java.util.regex.*;
import java.text.*;
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.geom.*;
import javax.imageio.*;
import javax.swing.*;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;

public class browse_jsp
{
		
	protected HttpServletRequest m_request;
	protected HttpServletResponse m_response;
	protected ServletContext m_application;
	protected PageContext m_pagecontext;
	protected PrintWriter out; 

	private ewebeditor.server.util myUtil;

	private String sFileSeparator;

	public browse_jsp(){
		myUtil = new ewebeditor.server.util();
		sFileSeparator = System.getProperty("file.separator");
	}


	public final void Load(PageContext pagecontext) throws ServletException,IOException
	{
		m_pagecontext = pagecontext;
		m_application = pagecontext.getServletContext();
		m_request = (HttpServletRequest)pagecontext.getRequest();
		m_response = (HttpServletResponse)pagecontext.getResponse();
		out = m_response.getWriter();

		InitUpload();
	}



	private void InitUpload() throws ServletException,IOException{

		String eWebEditorPath = m_request.getServletPath();
		eWebEditorPath = eWebEditorPath.substring(0, eWebEditorPath.lastIndexOf("/"));
		eWebEditorPath = eWebEditorPath.substring(0, eWebEditorPath.lastIndexOf("/"));
		eWebEditorPath = m_application.getRealPath(eWebEditorPath);
		
		if (eWebEditorPath.substring(eWebEditorPath.length()-1,eWebEditorPath.length()) != sFileSeparator){
			eWebEditorPath += sFileSeparator;
		}
		String sConfig = myUtil.ReadFile(eWebEditorPath+"jsp"+sFileSeparator+"config.jsp");
		ArrayList aStyle = myUtil.getConfigArray("Style", sConfig);

		String sAllowExt, sUploadDir, sBaseUrl, sContentPath;
		String sCurrDir, sDir;
		int nAllowBrowse, nCusDirFlag;
		String sPathShareImage, sPathShareFlash, sPathShareMedia, sPathShareOther;

		// param
		String sType = myUtil.dealNull(m_request.getParameter("type")).toUpperCase();
		String sStyleName = myUtil.dealNull(m_request.getParameter("style"));
		String sCusDir = myUtil.dealNull(m_request.getParameter("cusdir"));
		String sAction = myUtil.dealNull(m_request.getParameter("action")).toUpperCase();
		// InitUpload

		String[] aStyleConfig = new String[1];
		boolean bValidStyle = false;

		for (int i = 0; i < aStyle.size(); i++){
			aStyleConfig = myUtil.split(aStyle.get(i).toString(), "|||");
			if (sStyleName.toLowerCase().equals(aStyleConfig[0].toLowerCase())) {
				bValidStyle = true;
				break;
			}
		}

		if (!bValidStyle) {
			out.print(getOutScript("alert('Invalid Style!')"));
			out.close();
			return;
		}

		sBaseUrl = aStyleConfig[19];
		nAllowBrowse = Integer.valueOf(aStyleConfig[43]).intValue();
		nCusDirFlag = Integer.valueOf(aStyleConfig[61]).intValue();

		if (nAllowBrowse!=1){
			out.print(getOutScript("alert('Do not allow browse!')"));
			out.close();
			return;
		}
		if (nCusDirFlag!=1){
			sCusDir = "";
		}else{
			if (!sCusDir.equals("")){
				sCusDir = myUtil.replace(sCusDir, "\\", "/");
				if ((sCusDir.startsWith("/")) || (sCusDir.startsWith(".")) || (sCusDir.endsWith(".")) || (sCusDir.indexOf("./")>=0) || (sCusDir.indexOf("/.")>=0) || (sCusDir.indexOf("//")>=0)){
					sCusDir = "";
				}else{
					if (!sCusDir.endsWith("/")){
						sCusDir = sCusDir + "/";
					}
				}
			}
		}

		sUploadDir = aStyleConfig[3];
		if (!sBaseUrl.equals("3")){
			if (!sUploadDir.substring(0, 1).equals("/")) {
				sUploadDir = "../" + sUploadDir;
			}
			sUploadDir = m_application.getRealPath(RelativePath2RootPath2(sUploadDir));
		}
		sUploadDir = GetSlashPath(sUploadDir);
		sUploadDir = sUploadDir + myUtil.replace(myUtil.replace(sCusDir, "/", sFileSeparator), "\\", sFileSeparator);

		if (sType.equals("FILE")){
			sAllowExt = "";
		} else if (sType.equals("MEDIA")){
			sAllowExt = "rm|mp3|wav|mid|midi|ra|avi|mpg|mpeg|asf|asx|wma|mov";
		} else if (sType.equals("FLASH")){
			sAllowExt = "swf";
		} else {
			sAllowExt = "bmp|jpg|jpeg|png|gif";
		}


		sPathShareImage = GetSlashPath(m_application.getRealPath(RelativePath2RootPath2("../sharefile/image/")));
		sPathShareFlash = GetSlashPath(m_application.getRealPath(RelativePath2RootPath2("../sharefile/flash/")));
		sPathShareMedia = GetSlashPath(m_application.getRealPath(RelativePath2RootPath2("../sharefile/media/")));
		sPathShareOther = GetSlashPath(m_application.getRealPath(RelativePath2RootPath2("../sharefile/other/")));



		String s_Out = "";
		if (sAction.equals("FILE")) {

			String s_ReturnFlag = myUtil.dealNull(m_request.getParameter("returnflag"));
			String s_FolderType = myUtil.dealNull(m_request.getParameter("foldertype"));
			String s_Dir = myUtil.dealNull(m_request.getParameter("dir"));

			String s_CurrDir = "";
			if (s_FolderType.equals("upload")){
				s_CurrDir = sUploadDir;
			} else if (s_FolderType.equals("shareimage")){
				sAllowExt = "";
				s_CurrDir = sPathShareImage;
			} else if (s_FolderType.equals("shareflash")){
				sAllowExt = "";
				s_CurrDir = sPathShareFlash;
			} else if (s_FolderType.equals("sharemedia")){
				sAllowExt = "";
				s_CurrDir = sPathShareMedia;
			} else {
				s_FolderType = "shareother";
				sAllowExt = "";
				s_CurrDir = sPathShareOther;
			}

			s_Dir = myUtil.replace(s_Dir, "\\", "/");
			if ((s_Dir.startsWith("/")) || (s_Dir.startsWith(".")) || (s_Dir.endsWith(".")) || (s_Dir.indexOf("./")>=0) || (s_Dir.indexOf("/.")>=0) || (s_Dir.indexOf("//")>=0) || (s_Dir.indexOf("..")>=0)){
				s_Dir = "";
			}

			String s_Dir2 = myUtil.replace(s_Dir, "/", sFileSeparator);
			s_Dir2 = myUtil.replace(s_Dir2, "\\", sFileSeparator);

			if (!s_Dir.equals("")) {
				if (CheckValidDir(s_CurrDir+s_Dir2)){
					s_CurrDir += s_Dir2;
				}else{
					s_Dir = "";
				}
			}

			if (CheckValidDir(s_CurrDir)){
				File file = new File(s_CurrDir);
				File[] filelist = file.listFiles();
				if (filelist != null && filelist.length > 0){
					int n = -1;
					for (int i = 0; i < filelist.length; i++) {
						if (filelist[i].isFile()) {
							String s_FileName = filelist[i].getName();
							String s_FileExt = s_FileName.substring(s_FileName.lastIndexOf(".")+1);
							s_FileExt = s_FileExt.toLowerCase();
							if (CheckValidExt(sAllowExt, s_FileExt)){
								n++;
								s_Out = s_Out + "arr[" + String.valueOf(n) + "]=new Array(\"" + s_FileName + "\", \"" + String.valueOf(convertFileSize(filelist[i].length())) + "\",\"" + formatDate(new Date(filelist[i].lastModified())) + "\");\n";
							}
						}
					}
				}
			}

			s_Out = "var arr = new Array();\n" + s_Out + "parent.setFileList('" + s_ReturnFlag + "', '" + s_FolderType + "', '" + s_Dir + "', arr);";	
			out.print(getOutScript(s_Out));

		}else{

			s_Out = "var arrUpload = new Array();\n";
			s_Out += "var arrShareImage = new Array();\n";
			s_Out += "var arrShareFlash = new Array();\n";
			s_Out += "var arrShareMedia = new Array();\n";
			s_Out += "var arrShareOther = new Array();\n";
			
			s_Out += GetFolderTree(sUploadDir, "Upload", 1, 0).get(0).toString();

			sAllowExt = "";
			if (sType.equals("FILE")){
				s_Out += GetFolderTree(sPathShareImage, "ShareImage", 1, 0).get(0).toString();
				s_Out += GetFolderTree(sPathShareFlash, "ShareFlash", 1, 0).get(0).toString();
				s_Out += GetFolderTree(sPathShareMedia, "ShareMedia", 1, 0).get(0).toString();
				s_Out += GetFolderTree(sPathShareOther, "ShareOther", 1, 0).get(0).toString();
			} else if (sType.equals("MEDIA")){
				s_Out += GetFolderTree(sPathShareMedia, "ShareMedia", 1, 0).get(0).toString();
			} else if (sType.equals("FLASH")){
				s_Out += GetFolderTree(sPathShareFlash, "ShareFlash", 1, 0).get(0).toString();
			} else {
				s_Out += GetFolderTree(sPathShareImage, "ShareImage", 1, 0).get(0).toString();
			}

			s_Out += "parent.setFolderList(arrUpload, arrShareImage, arrShareFlash, arrShareMedia, arrShareOther);";
			out.print(getOutScript(s_Out));
		}


	}


	private String GetSlashPath(String str){
		if (!str.endsWith(sFileSeparator)){
			return str+sFileSeparator;
		}
		return str;
	}


	private String getOutScript(String str){
		String html = "";
		html += "<HTML><HEAD><meta http-equiv='Content-Type' content='text/html; charset=gb2312'><TITLE>eWebEditor</TITLE></head><body>";
		html += "<script language=javascript>" + str + "</script>";
		html += "</body></html>";
		return html;
	}

	private boolean CheckValidExt(String s_AllowExt, String sExt){
		if(s_AllowExt.equals("")){
			return true;
		}
		String[] aExt = myUtil.split(s_AllowExt, "|");
		for (int i = 0; i<aExt.length; i++){
			if (aExt[i].toLowerCase().equals(sExt)) {
				return true;
			}
		}
		return false;
	}


	private ArrayList GetFolderTree(String s_Dir, String s_Flag, int n_Indent, int n_TreeIndex){
		String s_List = "";
		ArrayList aSubFolders = new ArrayList();

		File file = new File(s_Dir);
		File[] filelist = file.listFiles();

		if (filelist != null && filelist.length > 0){
			for (int i = 0; i < filelist.length; i++) {
				if (filelist[i].isDirectory()) {
					aSubFolders.add(filelist[i].getName());
				}
			}

			int n_Count = aSubFolders.size();
			String s_LastFlag = "";
			String s_Folder = "";
			for (int i=1; i<=n_Count; i++){
				if (i < n_Count){
					s_LastFlag = "0";
				}else{
					s_LastFlag = "1";
				}

				s_Folder = aSubFolders.get(i-1).toString();
				s_List = s_List + "arr" + s_Flag + "[" + String.valueOf(n_TreeIndex) + "]=new Array(\"" + s_Folder + "\"," + String.valueOf(n_Indent) + ", " + s_LastFlag + ");\n";
				n_TreeIndex = n_TreeIndex + 1;
				ArrayList a_Temp = GetFolderTree(s_Dir + s_Folder + sFileSeparator, s_Flag, n_Indent+1, n_TreeIndex);
				s_List = s_List + a_Temp.get(0).toString();
				n_TreeIndex = Integer.valueOf(a_Temp.get(1).toString()).intValue();
			}
		}

		ArrayList a_Return = new ArrayList();
		a_Return.add(s_List);
		a_Return.add(String.valueOf(n_TreeIndex));
		return a_Return;
	}

	private boolean CheckValidDir(String path){
		java.io.File dir = new java.io.File(path);
		if (dir == null){
			return false;
		}
		if (dir.isFile()){
			return false;
		}
		if (!dir.exists()){
			return false;
		}
		return true;
	}

	private String RelativePath2RootPath2(String url){
		String sTempUrl = url;
		if (sTempUrl.substring(0, 1).equals("/")){
			return sTempUrl;
		}

		String sWebEditorPath = m_request.getServletPath();
		sWebEditorPath = sWebEditorPath.substring(0, sWebEditorPath.lastIndexOf("/"));
		while(sTempUrl.startsWith("../")){
			sTempUrl = sTempUrl.substring(3);
			sWebEditorPath = sWebEditorPath.substring(0, sWebEditorPath.lastIndexOf("/"));
		}
		return sWebEditorPath + "/" + sTempUrl;
	}

	private String convertFileSize (long size){
		int divisor = 1024;
		String unit = "K";
		if (divisor ==1) return size /divisor + " "+unit;
		String aftercomma = ""+100*(size % divisor)/divisor;
		if (aftercomma.length() == 1) aftercomma="0"+aftercomma;
		return size /divisor + "."+aftercomma+" "+unit;
	}

	private String formatDate(Date myDate) {
		String strFormat = "yyyy-MM-dd HH:mm:ss";
		SimpleDateFormat formatter = new SimpleDateFormat(strFormat);
		String strDate = formatter.format(myDate);
		return strDate;
	}






}
